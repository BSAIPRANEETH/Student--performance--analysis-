"""
Student Performance & Data Analysis System
Entry-level Python project.

Run:
    python student_performance.py
"""

students = [
    {"name": "Aarav", "python": 82, "sql": 76, "communication": 88},
    {"name": "Priya", "python": 91, "sql": 84, "communication": 79},
    {"name": "Rahul", "python": 68, "sql": 72, "communication": 75},
    {"name": "Sneha", "python": 78, "sql": 89, "communication": 92},
    {"name": "Kiran", "python": 55, "sql": 61, "communication": 64},
]

def calculate_average(student):
    scores = [student["python"], student["sql"], student["communication"]]
    return sum(scores) / len(scores)

def get_grade(average):
    if average >= 85:
        return "A"
    if average >= 70:
        return "B"
    if average >= 60:
        return "C"
    return "D"

def build_report(records):
    report = []
    for student in records:
        average = calculate_average(student)
        report.append({
            "name": student["name"],
            "average": round(average, 2),
            "grade": get_grade(average)
        })
    return report

def main():
    report = build_report(students)
    print("\nSTUDENT PERFORMANCE REPORT")
    print("-" * 45)
    for item in report:
        print(f"{item['name']:<12} Average: {item['average']:>6}  Grade: {item['grade']}")

    top_student = max(report, key=lambda x: x["average"])
    print("-" * 45)
    print(f"Top performer: {top_student['name']} ({top_student['average']})")

if __name__ == "__main__":
    main()
